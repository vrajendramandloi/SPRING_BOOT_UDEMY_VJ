package com.vicky.uni.example.startProject.SP1SpringBootInitApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sp1SpringBootInitAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sp1SpringBootInitAppApplication.class, args);
	}

}

package com.vicky.uni.example.startProject.SP1SpringBootInitApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sp1SpringBootInitAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
